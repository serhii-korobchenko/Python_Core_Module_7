#from clean_folder.clean import search_function


#__all__ = ['search_function']